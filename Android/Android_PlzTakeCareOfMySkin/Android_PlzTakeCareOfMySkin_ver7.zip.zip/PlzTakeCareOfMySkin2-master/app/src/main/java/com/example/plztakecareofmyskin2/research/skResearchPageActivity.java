package com.example.plztakecareofmyskin2.research;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.example.plztakecareofmyskin2.R;
import com.example.plztakecareofmyskin2.results.diseaseInfoPageActivity;
import com.example.plztakecareofmyskin2.results.melanomaPageActivity;
import com.example.plztakecareofmyskin2.results.nevusPageActivity;

public class skResearchPageActivity extends AppCompatActivity {

    TextView diagnoseQuestion, diagnoseQuestion2;
    RadioGroup radioGroup1, radioGroup2;
    Button resultBut;
    int flag1, flag2;
    int result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sk_research_page);

        diagnoseQuestion = findViewById(R.id.diagnoseQuestion);
        diagnoseQuestion2 = findViewById(R.id.diagnoseQuestion2);
        radioGroup1 = findViewById(R.id.radio_group1);
        radioGroup2 = findViewById(R.id.radio_group2);
        resultBut = findViewById(R.id.resultBut);

        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch(i) {
                    case R.id.yes1:
                        flag1 = 1;
                        Log.d("yes1", "yes1");
                        break;
                    case R.id.no1:
                        flag2 = 0;
                        break;
                }
            }
        });

        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch(i) {
                    case R.id.yes2:
                        flag2 = 1;
                        Log.d("yes2", "yes2");
                        break;
                    case R.id.no2:
                        flag2 = 0;
                        break;
                }
            }
        });

        resultBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                result = checkFlag(flag1, flag2);
                String diseaseName = intent.getStringExtra("diseaseName");
                if(result == 1) {
                    intent = new Intent(getApplicationContext(), diseaseInfoPageActivity.class);
                    intent.putExtra("diseaseName", "returnedMelanoma");
                } else {
                    if(diseaseName.equals("nevus")) {
                        intent = new Intent(getApplicationContext(), nevusPageActivity.class);
                    } else {
                        intent = new Intent(getApplicationContext(), diseaseInfoPageActivity.class);
                        intent.putExtra("diseaseName", "returnedSK");
                    }
                }
                startActivity(intent);
            }
        });
    }

    public int checkFlag(int flag1, int flag2) {
        if(flag1 == 1 && flag2 == 1) return 1;
        else return 0;
    }
}
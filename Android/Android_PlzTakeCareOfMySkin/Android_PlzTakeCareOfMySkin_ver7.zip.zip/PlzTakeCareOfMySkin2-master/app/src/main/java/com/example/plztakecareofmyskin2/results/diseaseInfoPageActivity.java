package com.example.plztakecareofmyskin2.results;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.plztakecareofmyskin2.R;
import com.example.plztakecareofmyskin2.research.skResearchPageActivity;

public class diseaseInfoPageActivity extends AppCompatActivity {

    TextView diseaseText;
    Button infoBut, nearHospitalBut;
    Intent intent, nearIntent, infoIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disease_info_page);

        diseaseText = findViewById(R.id.diseaseTextView);
        infoBut = findViewById(R.id.infoBut);
        nearHospitalBut = findViewById(R.id.nearHospitalBut);

        intent = getIntent();
        String diseaseName = intent.getStringExtra("diseaseName");

        infoIntent = new Intent(Intent.ACTION_VIEW);

        // 질병명 따라 분기 처리
        if (diseaseName.equals("melanoma") || diseaseName.equals("returnedMelanoma")) {
            diseaseText.setText("흑색종 의심!");
            nearIntent = new Intent(this, melanomaPageActivity.class);
            infoIntent.setData(Uri.parse("https://www.amc.seoul.kr/asan/healthinfo/disease/diseaseDetail.do?contentId=32475"));
        } else if (diseaseName.equals("returnedSK")) {
                diseaseText.setText("검버섯");
                nearIntent = new Intent(this, skPageActivity.class);
                infoIntent.setData(Uri.parse("https://www.derma.or.kr/new/general/disease.php?uid=5187&mod=document"));
        } else {
            intent = new Intent(this, skResearchPageActivity.class);
            intent.putExtra("diseaseName", diseaseName);
            startActivity(intent);
        }

        infoBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(infoIntent);
            }
        });

        nearHospitalBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(nearIntent);
            }
        });
    }
}
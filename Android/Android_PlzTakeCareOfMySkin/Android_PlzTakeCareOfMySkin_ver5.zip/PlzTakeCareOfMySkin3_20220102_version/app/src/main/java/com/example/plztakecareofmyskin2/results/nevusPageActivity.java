package com.example.plztakecareofmyskin2.results;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.plztakecareofmyskin2.R;

public class nevusPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nevus_page);
    }
}
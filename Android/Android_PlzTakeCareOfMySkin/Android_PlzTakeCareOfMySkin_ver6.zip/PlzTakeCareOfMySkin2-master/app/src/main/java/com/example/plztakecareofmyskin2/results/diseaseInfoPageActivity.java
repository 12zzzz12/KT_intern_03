package com.example.plztakecareofmyskin2.results;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.plztakecareofmyskin2.R;
import com.example.plztakecareofmyskin2.research.skResearchPageActivity;

public class diseaseInfoPageActivity extends AppCompatActivity {

    TextView diseaseText;
    Button infoBut, nearHospitalBut;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disease_info_page);

        diseaseText = findViewById(R.id.diseaseTextView);
        infoBut = findViewById(R.id.infoBut);
        nearHospitalBut = findViewById(R.id.nearHospitalBut);

        intent = getIntent();
        String diseaseName = intent.getStringExtra("diseaseName");
        String probability = intent.getStringExtra("probability");
        Float pValue = Float.parseFloat(probability);
        Log.d("pValue", pValue.toString());

        // 질병명 따라 분기 처리
        if (diseaseName.equals("melanoma")) {
            diseaseText.setText("흑색종 의심!");
            intent = new Intent(this, melanomaPageActivity.class);
        } else if (diseaseName.equals("seborrheic_keratosis")) {
            if (pValue < 70) {
                diseaseText.setVisibility(View.INVISIBLE);
                infoBut.setVisibility(View.INVISIBLE);
                nearHospitalBut.setVisibility(View.INVISIBLE);
                intent = new Intent(this, skResearchPageActivity.class);
                startActivity(intent);
            } else {
                diseaseText.setText("검버섯");
                intent = new Intent(this, skPageActivity.class);
            }
        } else {
            diseaseText.setText("점");
            infoBut.setVisibility(View.INVISIBLE);
            nearHospitalBut.setVisibility(View.INVISIBLE);
            intent = new Intent(this, nevusPageActivity.class);
            startActivity(intent);
        }

        nearHospitalBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });
    }
}
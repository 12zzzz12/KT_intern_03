package com.example.plztakecareofmyskin.ui.home;
//
//import static android.content.Context.LOCATION_SERVICE;
//
//import android.Manifest;
//import android.app.AlertDialog;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.location.Location;
//import android.location.LocationManager;
//import android.os.Bundle;
//import android.os.Looper;
//import android.provider.Settings;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//import androidx.fragment.app.Fragment;
//
//import com.example.plztakecareofmyskin.R;
//import com.google.android.gms.location.FusedLocationProviderClient;
//import com.google.android.gms.location.LocationCallback;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationResult;
//import com.google.android.gms.location.LocationServices;
//import com.google.android.gms.location.LocationSettingsRequest;
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.MapView;
//import com.google.android.gms.maps.OnMapReadyCallback;
//import com.google.android.gms.maps.SupportMapFragment;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.Marker;
//import com.google.android.gms.maps.model.MarkerOptions;
//
//import java.lang.reflect.Array;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//
//import noman.googleplaces.NRPlaces;
//import noman.googleplaces.Place;
//import noman.googleplaces.PlacesException;
//import noman.googleplaces.PlacesListener;
//
//public class HospitalMapActivity extends Fragment implements OnMapReadyCallback, PlacesListener {
//    private static final String TAG = "HospitalMapActivity";
//    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
//    private GoogleMap mGoogleMap;
//
//    Location mCurrentLocation;
//    LatLng mCurrentPostionLatLng;
//
//    private FusedLocationProviderClient mFusedLocationClient;
//    private LocationRequest mLocationRequest;
//    private Location mLocation;
//    private List<Marker> mPrivious_maker = null;
//
//    LocationSettingsRequest.Builder builder;
//
//    private short updateHospitalInfo = 0;
//
//    public View onCreateView(@NonNull LayoutInflater inflater,
//                             ViewGroup container, Bundle savedInstanceState) {
//
//        View root = inflater.inflate(R.layout.activity_hospital_map, container, false);
//
//        mLocationRequest = LocationRequest.create()
//                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
//                .setInterval(1000)
//                .setFastestInterval(500)
//                .setNumUpdates(5);
//
//        builder = new LocationSettingsRequest.Builder();
//
//        builder.addLocationRequest(mLocationRequest);
//
//        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());
//
//        mPrivious_maker = new ArrayList<Marker>();
//
//        MapView mapFragment = (MapView) root.findViewById(R.id.map);
//        mapFragment.onCreate(savedInstanceState);
//
//        mapFragment.getMapAsync(this);
//
//        return root;
//    }
//
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        this.mGoogleMap = googleMap;
//
//        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
//                ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
//            googleMap.setMyLocationEnabled(true);
//
//            startLocationUpdates();
//        } else {
//            checkLocationPermissionWithRationale();
//        }
//    }
//
//    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
//
//    private void checkLocationPermissionWithRationale() {
//        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
//                new AlertDialog.Builder(getContext())
//                        .setTitle("위치정보")
//                        .setMessage("이 앱을 사용하기 위해서는 위치정보에 접근이 필요합니다. 위치정보 접근을 허용해주세요.")
//                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
//                            }
//                        }).create().show();
//            } else {
//                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
//            }
//
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
//        switch (requestCode) {
//            case MY_PERMISSIONS_REQUEST_LOCATION:
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
//                        mGoogleMap.setMyLocationEnabled(true);
//                    } else {
//                        Toast.makeText(getContext(), "permission deined", Toast.LENGTH_LONG).show();
//                    }
//                    return;
//                }
//        }
//    }
//
//    LocationCallback locationCallback = new LocationCallback() {
//        @Override
//        public void onLocationResult(@NonNull LocationResult locationResult) {
//            super.onLocationResult(locationResult);
//
//            List<Location> locationList = locationResult.getLocations();
//
//            if (locationList.size() > 0) {
//                mLocation = locationList.get(locationList.size() - 1);
//
//                mCurrentPostionLatLng
//                        = new LatLng(mLocation.getLatitude(), mLocation.getLongitude());
//
//                mCurrentLocation = mLocation;
//
//                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(mCurrentPostionLatLng));
//                mGoogleMap.moveCamera(CameraUpdateFactory.zoomTo(15));
//                MarkerOptions markerOptions = new MarkerOptions().position(mCurrentPostionLatLng).title("현재 위치");
//                mGoogleMap.addMarker(markerOptions);
//
//                if (updateHospitalInfo <= 10) {
//                    showPlaceInformation(mCurrentPostionLatLng);
//                    updateHospitalInfo++;
//                }
//            }
//        }
//    };
//
//    private void startLocationUpdates() {
//        if (!checkLocationServiceStatus()) {
//            Log.d(TAG, "sartLocationUpdates : call ShowDialogForLocationServiceSetting");
//            showDialogForLocationServiceSetting();
//        } else {
//            int hasFineLocationPermission = ContextCompat.checkSelfPermission(getContext(),
//                    Manifest.permission.ACCESS_FINE_LOCATION);
//            int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(getContext(),
//                    Manifest.permission.ACCESS_COARSE_LOCATION);
//
//            if (hasFineLocationPermission != PackageManager.PERMISSION_GRANTED ||
//                    hasCoarseLocationPermission != PackageManager.PERMISSION_GRANTED) {
//
//                Log.d(TAG, "startLocationUpdates : 퍼미션 안가지고 있음");
//                return;
//            }
//
//            Log.d(TAG, "startLocationUpdates : call mFusedLocationClient.requestLocationUpdates");
//
//            mFusedLocationClient.requestLocationUpdates(mLocationRequest, locationCallback, Looper.myLooper());
//
//            if (checkPermission())
//                mGoogleMap.setMyLocationEnabled(true);
//        }
//    }
//
//
//    public boolean checkLocationServiceStatus() {
//        LocationManager locationManager = (LocationManager) getActivity().getSystemService(LOCATION_SERVICE);
//
//        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
//                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
//    }
//
//    private boolean checkPermission() {
//        int hasFineLocationPermission = ContextCompat.checkSelfPermission(getContext(),
//                Manifest.permission.ACCESS_FINE_LOCATION);
//        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(getContext(),
//                Manifest.permission.ACCESS_COARSE_LOCATION);
//
//        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
//                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {
//            return true;
//        }
//
//        return false;
//    }
//
//    private void showDialogForLocationServiceSetting() {
//
//        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(getContext());
//        builder.setTitle("위치 서비스 비활성화");
//        builder.setMessage("앱을 사용하기 위해서는 위치 서비스 활성화가 필요합니다.\n"
//                + "위치 서비스 활성화를 진행하시겠습니까?");
//        builder.setCancelable(true);
//        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Intent callGPSSettingIntent
//                        = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE);
//            }
//        });
//        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.cancel();
//            }
//        });
//
//        builder.create().show();
//    }
//
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        switch (requestCode) {
//            case GPS_ENABLE_REQUEST_CODE:
//                if (checkLocationServiceStatus()) {
//                    Log.d(TAG, "onActivityResult: GPS Enabled");
//
//                    return;
//                }
//                break;
//        }
//    }
//
//
//    @Override
//    public void onPlacesFailure(PlacesException e) {
//
//    }
//
//    @Override
//    public void onPlacesStart() {
//
//    }
//
//    @Override
//    public void onPlacesSuccess(final List<Place> places) {
//        getActivity().runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                Log.d(TAG, "Places number = " + places.size());
//                for(noman.googleplaces.Place place : places) {
//                    LatLng mLatLng
//                            = new LatLng(place.getLatitude(), place.getLongitude());
//
//                    MarkerOptions markerOptions = new MarkerOptions();
//                    markerOptions.position(mLatLng);
//                    markerOptions.title(place.getName());
//                    Marker item = mGoogleMap.addMarker(markerOptions);
//                    mPrivious_maker.add(item);
//                }
//
//                // Duplicate Marker remove
//                HashSet<Marker> hashSet = new HashSet<Marker>();
//                hashSet.addAll(mPrivious_maker);
//                mPrivious_maker.clear();
//                mPrivious_maker.addAll(hashSet);
//            }
//        });
//    }
//
//    @Override
//    public void onPlacesFinished() {
//
//    }
//
//    public void showPlaceInformation(LatLng location) {
//        mGoogleMap.clear();
//
////        if(previous_maker != null)
////            previous_maker.clear();
//
//        new NRPlaces.Builder()
//                .listener(this)
//                .key("AIzaSyBCuGuTxO2Yj7mQcj8Xp_37Hd_3JYF4CWw")
//                .latlng(location.latitude, location.longitude)
//                .radius(5000)
//                .keyword("대학병원")
//                .type(null)
//                .build()
//                .execute();
//    }
//}

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.plztakecareofmyskin.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

import noman.googleplaces.PlacesListener;

public class HospitalMapActivity extends Fragment implements OnMapReadyCallback {
    private static final String TAG = "HospitalMapActivity";
    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
    private GoogleMap mGoogleMap;

    Location mCurrentLocation;
    LatLng mCurrentPosition;

    private FusedLocationProviderClient mFusedLocationClient;
    private LocationRequest locationRequest;
    private Location location;
    private List<Marker> previous_marker = null;

    LocationSettingsRequest.Builder builder;

    private short updateHospitalInfo = 0;

    Activity mActivity;
    Context mContext;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_hospital_map, container, false);

        mActivity = getActivity();
        mContext = getContext();

        locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(1000)
                .setFastestInterval(500)
                .setNumUpdates(5);

        builder = new LocationSettingsRequest.Builder();

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(mActivity);

        previous_marker = new ArrayList<Marker>();

        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;

        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);

            startLocationUpdates();
        } else {
            checkLocationPermissionWithRationale();
        }
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    private void checkLocationPermissionWithRationale() {
        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.ACCESS_FINE_LOCATION)) {
                new AlertDialog.Builder(mContext)
                        .setTitle("위치정보")
                        .setMessage("이 앱을 사용하기 위해서는 위치정보에 접근이 필요합니다. 위치정보 접근을 허용하여 주세요.")
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        }).create().show();
            } else {
                ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        mGoogleMap.setMyLocationEnabled(true);
                    }
                } else {
                    Toast.makeText(mContext, "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            super.onLocationResult(locationResult);

            List<Location> locationList = locationResult.getLocations();

            if (locationList.size() > 0) {
                location = locationList.get(locationList.size() - 1);

                mCurrentPosition
                        = new LatLng(location.getLatitude(), location.getLongitude());

                mCurrentLocation = location;

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(mCurrentPosition));
                mGoogleMap.moveCamera(CameraUpdateFactory.zoomTo(15));
                MarkerOptions markerOptions = new MarkerOptions().position(mCurrentPosition).title("현재 위치");
                mGoogleMap.addMarker(markerOptions);

//                if(updateHospitalInfo <= 10) {
//                    showPlaceInformation(mCurrentPosition);
//                    updateHospitalInfo++;
//                }
            }
        }
    };


    private void startLocationUpdates() {
        if (!checkLocationServiceStatus()) {
            Log.d(TAG, "startLocationUpdates : call showDialogForLocationServiceSetting");
            showDialogForLocationServiceSetting();
        } else {
            int hasFineLocationPermission = ContextCompat.checkSelfPermission(mContext,
                    Manifest.permission.ACCESS_FINE_LOCATION);
            int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(mContext,
                    Manifest.permission.ACCESS_COARSE_LOCATION);

            if (hasFineLocationPermission != PackageManager.PERMISSION_GRANTED ||
                    hasCoarseLocationPermission != PackageManager.PERMISSION_GRANTED) {

                Log.d(TAG, "startLocationUpdates : 퍼미션 안가지고 있음");
                return;
            }

            Log.d(TAG, "startLocationUpdates : call mFusedLocationClient.requestLocationUpdates");

            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

            if (checkPermission())
                mGoogleMap.setMyLocationEnabled(true);
        }
    }

    public boolean checkLocationServiceStatus() {
        LocationManager locationManager = (LocationManager) mActivity.getSystemService(Context.LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private boolean checkPermission() {
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.ACCESS_COARSE_LOCATION);

        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {
            return true;
        }

        return false;
    }

    private void showDialogForLocationServiceSetting() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle("위치 서비스 비활성화");
        builder.setMessage("앱을 사용하기 위해서는 위치 서비스 활성화가 필요합니다.\n"
                + "위치 서비스 활성화를 진행하시겠습니까?");
        builder.setCancelable(true);
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent callGPSSettingIntent
                        = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.create().show();
    }

}
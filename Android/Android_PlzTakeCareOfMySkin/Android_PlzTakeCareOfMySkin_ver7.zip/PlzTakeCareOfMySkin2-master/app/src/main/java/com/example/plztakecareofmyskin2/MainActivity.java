package com.example.plztakecareofmyskin2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
//                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                R.id.navigation_home, R.id.navigation_camera, R.id.navigation_maps)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                Log.d(TAG, "#onNavigationItemSelected id = [" + id + "]");

                switch (id) {
                    case R.id.navigation_home:
                        Log.d(TAG, "R.id.navigation_home is called");
                        navController.navigate(R.id.navigation_home);
                        return true;

                    case R.id.navigation_camera:
                        Log.d(TAG, "R.id.navigation_camera is called");
                        navController.navigate(R.id.camera_layout);
                        return true;

                    case R.id.navigation_maps:
                        Log.d(TAG, "R.id.navigation_notifications is called");
                        navController.navigate(R.id.hospital_map);
                        return true;
                    default:
                }
                return false;
            }
        });
    }
}
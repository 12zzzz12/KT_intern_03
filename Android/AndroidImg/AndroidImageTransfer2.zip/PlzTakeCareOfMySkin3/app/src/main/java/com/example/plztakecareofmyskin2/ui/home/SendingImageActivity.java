package com.example.plztakecareofmyskin2.ui.home;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.error.VolleyError;
import com.example.plztakecareofmyskin2.R;
import com.example.plztakecareofmyskin2.util.ByteArrayMultiPartRequest;
import com.example.plztakecareofmyskin2.util.VolleySingletonRQ;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SendingImageActivity extends AppCompatActivity {
    private final String AiServerUrl = "http://172.30.1.22:5000/pic";

    private TextView diseaseTextView;
    private Button goSiteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sending_image);

        diseaseTextView = findViewById(R.id.diseaseTextView);

        Intent intent = getIntent();
        Uri uri = Uri.parse(intent.getStringExtra("uri"));
        String imgPath = intent.getStringExtra("imgPath");
        final ImageButton thumbnailImageButton = findViewById(R.id.thumbnailImageButton);

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 8;
        Bitmap src = BitmapFactory.decodeFile(imgPath, options);
        Bitmap resized = Bitmap.createScaledBitmap(src, 1800, 1200, true);
        Matrix matrix = new Matrix();
        matrix.preRotate(90, 0, 0);
        // 사진을 가져와서 bitmap 형식으로 변환
        Bitmap created = Bitmap.createBitmap(resized, 0, 0, resized.getWidth(), resized.getHeight(), matrix, false);
        // imageView로 set해서 화면에 보여줌
        thumbnailImageButton.setImageBitmap(created);

        Bitmap doubleResized = Bitmap.createScaledBitmap(src, 900, 600, false);
        Bitmap doubleRotated = Bitmap.createBitmap(doubleResized, 0, 0, doubleResized.getWidth(), doubleResized.getHeight(), matrix, false);

        goSiteButton = findViewById(R.id.goSiteButton);
        goSiteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToSiteIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.naver.com"));
                startActivity(goToSiteIntent);
            }
        });

        // 찍은 사진을 서버로 보내는 부분
        final Button submitToServerButton = findViewById(R.id.submitToServerButton);
        submitToServerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("server", "서버 제출 버튼");

                // onResponse로 Response.Listener 객체 생성
                // 서버 url로 접속 시도
                ByteArrayMultiPartRequest byteArrayMultiPartRequest = new ByteArrayMultiPartRequest(Request.Method.POST, AiServerUrl, new Response.Listener<byte[]>() {
                    @Override
                    public void onResponse(byte[] response) {
                        Log.d("server", "ai 서버 성공" + response);
                        Bitmap bitmap = byteArrayToBitMap(response); // 서버에서 바이트로 들어오는 사진을 bitmap으로 변환
                        Bitmap sizeChangedBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth()*2, bitmap.getHeight()*2, false);
                        thumbnailImageButton.setImageBitmap(sizeChangedBitmap);

                        diseaseTextView.setText("result");
                        submitToServerButton.setVisibility(View.INVISIBLE);
                        goSiteButton.setVisibility(View.VISIBLE);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("AIserver", error.toString());
                    }
                });

                String imageFileName = saveBitmapToCache(doubleRotated);
                String imageFilePath = getFilePathFromCache(imageFileName);

                // "file"이라는 이름으로, imageFilePath에 해당하는 사진을 String형식으로 upload 요청을 저장
                // 이 때 통신을 위해서 volley를 사용
                byteArrayMultiPartRequest.addFile("file", imageFilePath);

                // volley의 requestQueue에 저장
                VolleySingletonRQ.getInstance(getApplicationContext()).addToRequestQueue(byteArrayMultiPartRequest);
            }
        });
    }

    //
    private Bitmap byteArrayToBitMap(byte[] bytes) {
        try {
            // Decode an immutable bitmap from the specified byte array.
            // byte객체로부터 bitmap 해독해서 bitmap 리턴
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            Log.d("server", "byte to bitmap");
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }

    public String saveBitmapToCache(Bitmap bitmap){
        File storage = getCacheDir();
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy_MM_dd'T'HH_mm_ss");
        String fileName = simpleDateFormat.format(date)+".jpg";
        File tempFile = new File(storage, fileName);

        try {
            // 자동으로 빈 파일을 생성합니다.
            tempFile.createNewFile();

            // 파일을 쓸 수 있는 스트림을 준비합니다.
            FileOutputStream out = new FileOutputStream(tempFile);

            // compress 함수를 사용해 스트림에 비트맵을 저장합니다.
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);

            // 스트림 사용후 닫아줍니다.
            out.close();

        } catch (FileNotFoundException e) {
            Log.e("MyTag","FileNotFoundException : " + e.getMessage());
        } catch (IOException e) {
            Log.e("MyTag","IOException : " + e.getMessage());
        }
        return fileName;
    }

    public String getFilePathFromCache(String fileName){
        File file = new File(getCacheDir().toString());
        String filePath = file.getAbsolutePath() + "/" + fileName;
        Log.d("imagePath", filePath);
        return filePath;
    }
}
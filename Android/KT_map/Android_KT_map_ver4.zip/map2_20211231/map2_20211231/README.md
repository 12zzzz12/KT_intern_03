# sample.google.map

현재 위치 버튼이 활성화된 구글 지도를 표시하고, 홍대입구역 위치에 마커를 표시하는 샘플 어플리케이션입니다.  
구글지도 표시를 위해 만드시 AndroidManifest.xml 파일안에 구글 클라우스 서비스의 API 키를 복사하세요.  

<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="{여기에 API 키를 복사하세요}" />

API 키를 발급 받는 방법, 안전하게 API 키를 사용하기 위해 제한을 설정하는 방법을 설명하고, 아울러 샘플 소스코드의 설명이 필요하신 분은 아래 영상을 참조하세요.  

https://youtu.be/mLqBNdqYEQw

![Screenshot](support/youtube_thumbnail_googlemap.png)

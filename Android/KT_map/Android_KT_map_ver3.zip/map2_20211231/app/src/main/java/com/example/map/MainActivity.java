package com.example.map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import noman.googleplaces.NRPlaces;
import noman.googleplaces.Place;
import noman.googleplaces.PlaceType;
import noman.googleplaces.PlacesException;
import noman.googleplaces.PlacesListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, PlacesListener {

    private static final String TAG = "MainActivity";
    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
    private GoogleMap googleMap;

    Location mCurrentLocation;
    LatLng currentPosition;

    private FusedLocationProviderClient mFusedLocationClient;
    private LocationRequest locationRequest;
    private Location location;
    private List<Marker> previous_maker = null;

    LocationSettingsRequest.Builder builder;

    private short updateHospitalInfo = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //사용자 위치 업데이트, 가장 가까운 우치(즉, 사용자 위치 업데이트)
        locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(1000)
                .setFastestInterval(500)
                .setNumUpdates(5);

        builder = new LocationSettingsRequest.Builder();

        builder.addLocationRequest(locationRequest);
        //위도와 경도 가지고 온다(마지막으로 알려진 위치 가져오기)
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        previous_maker = new ArrayList<Marker>();

        //객체의 수명 주기를 관리하기 위한 fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        //지도 객체를 얻으려면 OnMapReadCallback 인터페이스를 구현한 클래스를 getMapAsync()함수를 이용하여 등록
    }

    @Override
    //getMapAsync()함수에 등록되 지도 객체를 사용할때 onMapReady() 함수가 자동으로 호출되며 GoogleMAp 객체가 전달됨
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
//        LatLng latLng = new LatLng(37.358832, 127.114850);
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
//        googleMap.moveCamera(CameraUpdateFactory.zoomTo(15));
//        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("KT분당사옥");
//        googleMap.addMarker(markerOptions);

        //자신의 현재 위치를 파악할 수 있게 허용
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);

            startLocationUpdates();
        } else {
            checkLocationPermissionWithRationale();
        }
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    private void checkLocationPermissionWithRationale() {
       //앱에 이미 권한이 부여되었는지 확인인
       if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //앱에 권한이 필요한 이유를 설명하는 코드 & 권한 요청
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                new AlertDialog.Builder(this)
                        .setTitle("위치정보")
                        .setMessage("이 앱을 사용하기 위해서는 위치정보에 접근이 필요합니다. 위치정보 접근을 허용하여 주세요.")
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        }).create().show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    // requestPermission의 배열의 index가 아래 grantResults index와 매칭
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) { //
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        googleMap.setMyLocationEnabled(true);
                        // TODO : 퍼미션이 승인 되면
                    }
                } else { // TODO : 퍼미션이 승인 거부 되면
                    Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();

                }
                return;
            }
        }
    }

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        //위치 요청
        public void onLocationResult(@NonNull LocationResult locationResult) {
            super.onLocationResult(locationResult);

            List<Location> locationList = locationResult.getLocations();

            if (locationList.size() > 0) {
                location = locationList.get(locationList.size() - 1);

                currentPosition
                        = new LatLng(location.getLatitude(), location.getLongitude());

                mCurrentLocation = location;

                googleMap.moveCamera(CameraUpdateFactory.newLatLng(currentPosition));
                googleMap.moveCamera(CameraUpdateFactory.zoomTo(15));
                MarkerOptions markerOptions = new MarkerOptions().position(currentPosition).title("현재 위치");
                googleMap.addMarker(markerOptions);

                //위치를 10번 요청함 (최소 위치를 잡을 수 있는 수를 찾음)
                if(updateHospitalInfo <= 10) {
                    showPlaceInformation(currentPosition);
                    updateHospitalInfo++;
                }
            }
        }
    };

    private void startLocationUpdates() {
        if (!checkLocationServiceStatus()) {
            Log.d(TAG, "startLocationUpdates : call showDialogForLocationServiceSetting");
            showDialogForLocationServiceSetting();
        } else {
            int hasFineLocationPermission = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION);
            int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION);

            if (hasFineLocationPermission != PackageManager.PERMISSION_GRANTED ||
                    hasCoarseLocationPermission != PackageManager.PERMISSION_GRANTED) {

                Log.d(TAG, "startLocationUpdates : 퍼미션 안가지고 있음");
                return;
            }

            Log.d(TAG, "startLocationUpdates : call mFusedLocationClient.requestLocationUpdates");

            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

            if (checkPermission())
                googleMap.setMyLocationEnabled(true);
        }
    }

    public boolean checkLocationServiceStatus() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private boolean checkPermission() {
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION);

        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {
            return true;
        }

        return false;
    }

    private void showDialogForLocationServiceSetting() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("위치 서비스 비활성화");
        builder.setMessage("앱을 사용하기 위해서는 위치 서비스 활성화가 필요합니다.\n"
                + "위치 서비스 활성화를 진행하시겠습니까?");
        builder.setCancelable(true);
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent callGPSSettingIntent
                        = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case GPS_ENABLE_REQUEST_CODE:
                if (checkLocationServiceStatus()) {
                    Log.d(TAG, "onActivityResult: GPS Enabled");

                    return;
                }
                break;
        }
    }

    @Override
    public void onPlacesFailure(PlacesException e) {

    }

    @Override
    public void onPlacesStart() {

    }

    @Override
    public void onPlacesSuccess(final List<Place> places) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Places number = " + places.size());
                for(noman.googleplaces.Place place : places) {
                    LatLng mLatLng
                            = new LatLng(place.getLatitude(), place.getLongitude());

                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(mLatLng);
                    markerOptions.title(place.getName());
                    Marker item = googleMap.addMarker(markerOptions);
                    previous_maker.add(item);
                }

                // Duplicate Marker remove
                HashSet<Marker> hashSet = new HashSet<Marker>();
                hashSet.addAll(previous_maker);
                previous_maker.clear();
                previous_maker.addAll(hashSet);
            }
        });
    }

    @Override
    public void onPlacesFinished() {

    }

    //대학병원만 위치가 나오도록 설정
    public void showPlaceInformation(LatLng location) {
        googleMap.clear();

//        if(previous_maker != null)
//            previous_maker.clear();

        new NRPlaces.Builder()
                .listener(MainActivity.this)
                .key("AIzaSyBCuGuTxO2Yj7mQcj8Xp_37Hd_3JYF4CWw")
                .latlng(location.latitude, location.longitude)
                .radius(5000)  //5km이내
                .keyword("대학병원")
                .type(null)
                .build()
                .execute();
    }
}